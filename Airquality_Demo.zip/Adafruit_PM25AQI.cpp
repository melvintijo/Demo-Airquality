#include "Adafruit_PM25AQI.h"

/*!
 *  @brief  Instantiates a new PM25AQI class
 */
Adafruit_PM25AQI::Adafruit_PM25AQI() {}

bool Adafruit_PM25AQI::begin()
{
  Wire.begin();
  return true;
}

/*!
 *  @brief  Setups the hardware and detects a valid UART PM2.5
 *  @param  data
 *          Pointer to PM25_AQI_Data that will be filled by read()ing
 *  @return True on successful read, false if timed out or bad data
 */
bool Adafruit_PM25AQI::read(PM25_AQI_Data *data)
{
  uint8_t buffer[32];
  uint16_t sum = 0;
  int bytesRead;

  if (!data)
  {
    Serial.println("!data failed");
    return false;
  }

  Wire.requestFrom(PMSA003I_I2CADDR_DEFAULT, sizeof(buffer));

  bytesRead = Wire.readBytes((char *)buffer, sizeof(buffer));

  if (bytesRead != sizeof(buffer))
  {
    Serial.print("size mismatch of: ");
    Serial.println(bytesRead - sizeof(buffer));
    return false;
  }

  // Check that start byte is correct!
  if (buffer[0] != 0x42)
  {
    Serial.println("buffer[0] not 0x42");

    return false;
  }

  // get checksum ready
  for (uint8_t i = 0; i < 30; i++)
  {
    sum += buffer[i];
  }

  // The data comes in endian'd, this solves it so it works on all platforms
  uint16_t buffer_u16[15];
  for (uint8_t i = 0; i < 15; i++)
  {
    buffer_u16[i] = buffer[2 + i * 2 + 1];
    buffer_u16[i] += (buffer[2 + i * 2] << 8);
  }

  // put it into a nice struct :)
  memcpy((void *)data, (void *)buffer_u16, sizeof(PM25_AQI_Data));

  if (sum != data->checksum)
  {
    Serial.println("bad checksum");
    return false;
  }

  // success!
  Serial.println("Success!");
  return true;
}